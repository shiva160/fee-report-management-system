// Consume the newline character

// Consume the invalid input

// Consume the newline character

// User not found

// Consume the newline character
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.InputMismatchException;
import java.util.Scanner;
    
    public class FeeReportManagementSystem {
    
       
    
        private static final String JDBC_URL = "jdbc:mysql://localhost:3306/feereportdb";
        private static final String DB_USER = "shiva21";
        private static final String DB_PASSWORD = "s@12345";
    
        private static Connection connection;
    
        static {
            try {
                // Load the JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");
    
                // Establish the database connection
                connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
    
                // Ensure that the student table exists
                createStudentTable();
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    
      
    
        private static void createStudentTable() throws SQLException {
            String createTableSQL = "CREATE TABLE IF NOT EXISTS students (" +
                    "id INT PRIMARY KEY," +
                    "name VARCHAR(255) NOT NULL," +
                    "username VARCHAR(255) NOT NULL," +
                    "password VARCHAR(255) NOT NULL," +
                    "balance DOUBLE NOT NULL)";
            
            try (Statement statement = connection.createStatement()) {
                statement.executeUpdate(createTableSQL);
            }
        }
    
        private static void insertStudentData(int id, String name, String username, String password, double balance) {
            String insertDataSQL = "INSERT INTO students (id, name, username, password, balance) VALUES (?, ?, ?, ?, ?)";
    
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertDataSQL)) {
                preparedStatement.setInt(1, id);
                preparedStatement.setString(2, name);
                preparedStatement.setString(3, username);
                preparedStatement.setString(4, password);
                preparedStatement.setDouble(5, balance);
    
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    
        private static void addStudent(Scanner scanner) {
            try {
                if (userCount < MAX_STUDENTS) {
                    System.out.print("Enter student name: ");
                    String studentName = scanner.nextLine();
    
                    // Check if the student name is unique
                    if (!containsStudent(studentName)) {
                        
    
                        // Insert student information into the database
                        insertStudentData(studentIds[userCount - 1], studentName,
                                studentUsernames[userCount - 1], studentPasswords[userCount - 1], 0.0);
    
    
                        System.out.println("Student added successfully.");
                    } else {
                        System.out.println("Student with the same name already exists. Please enter a unique name.");
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine(); // Consume the invalid input
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }
        }
    
        private static void studentLogin(Scanner scanner) {
            System.out.print("Enter student username: ");
            String studentUsername = scanner.nextLine();
            System.out.print("Enter student password: ");
            String studentPassword = scanner.nextLine();
    
            // Verify login credentials against the database
            if (verifyStudentCredentials(studentUsername, studentPassword)) {
                int studentIndex = findUser(studentUsername);
                showStudentMenu(studentIndex, scanner);
            } else {
                System.out.println("Invalid student credentials. Please try again.");
            }
        }
    
        private static boolean verifyStudentCredentials(String studentUsername, String studentPassword) {
            String querySQL = "SELECT * FROM students WHERE username = ? AND password = ?";
    
            try (PreparedStatement preparedStatement = connection.prepareStatement(querySQL)) {
                preparedStatement.setString(1, studentUsername);
                preparedStatement.setString(2, studentPassword);
    
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    return resultSet.next(); // If a row is returned, credentials are valid
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
    
       
    }
    

    private static boolean containsStudent(String studentName) {
        for (int i = 0; i < userCount; i++) {
            if (studentNames[i] != null && studentNames[i].equals(studentName)) {
                return true;
            }
        }
        return false;
    }

    private static boolean containsStudentId(int studentId) {
        for (int i = 0; i < userCount; i++) {
            if (studentIds[i] == studentId) {
                return true;
            }
        }
        return false;
    }

    private static void updateStudentInformation(Scanner scanner) {
        try {
            System.out.print("Enter student username: ");
            String studentUsername = scanner.nextLine();

            int studentIndex = findUser(studentUsername);

            if (studentIndex != -1) {
                System.out.println("Current information for " + studentUsername + ":");
                System.out.println("1. Student Name: " + studentNames[studentIndex]);
                System.out.println("2. Student ID: " + studentIds[studentIndex]);
                System.out.println("3. Username: " + studentUsernames[studentIndex]);
                System.out.println("Enter the number(s) of the information(s) to update (comma-separated): ");
                String input = scanner.nextLine();
                String[] updateNumbers = input.split(",");

                for (String updateNumber : updateNumbers) {
                    int updateOption = Integer.parseInt(updateNumber.trim());
                    switch (updateOption) {
                        case 1:
                            System.out.print("Enter new student name: ");
                            studentNames[studentIndex] = scanner.nextLine();
                            break;
                        case 2:
                            System.out.print("Enter new student ID: ");
                            studentIds[studentIndex] = scanner.nextInt();
                            scanner.nextLine(); // Consume the newline character after nextInt()
                            break;
                        case 3:
                            System.out.print("Enter new username: ");
                            studentUsernames[studentIndex] = scanner.nextLine();
                            break;
                        default:
                            System.out.println("Invalid update option: " + updateOption);
                    }
                }

                System.out.println("Student information updated successfully.");
            } else {
                System.out.println("Student not found.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine(); // Consume the invalid input
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    private static void removeStudent(Scanner scanner) {
        try {
            System.out.print("Enter student username to remove: ");
            String studentUsername = scanner.nextLine();

            int studentIndex = findUser(studentUsername);

            if (studentIndex != -1) {
                // Remove the student from arrays
                for (int i = studentIndex; i < userCount - 1; i++) {
                    studentBalances[i] = studentBalances[i + 1];
                    studentNames[i] = studentNames[i + 1];
                    studentUsernames[i] = studentUsernames[i + 1];
                    studentPasswords[i] = studentPasswords[i + 1];
                    studentIds[i] = studentIds[i + 1];
                }

                // Reset the last element to null
                studentBalances[userCount - 1] = 0.0;
                studentNames[userCount - 1] = null;
                studentUsernames[userCount - 1] = null;
                studentPasswords[userCount - 1] = null;
                studentIds[userCount - 1] = 0;

                userCount--;

                System.out.println("Student removed successfully.");
            } else {
                System.out.println("Student not found.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    private static void recordPayment(Scanner scanner) {
        try {
            System.out.print("Enter student username: ");
            String studentUsername = scanner.nextLine();

            int studentIndex = findUser(studentUsername);

            if (studentIndex != -1) {
                System.out.print("Enter payment amount: ");
                double paymentAmount = scanner.nextDouble();
                scanner.nextLine(); // Consume the newline character after nextDouble()

                if (paymentAmount > 0) {
                    studentBalances[studentIndex] += paymentAmount;
                    System.out.println("Payment recorded successfully.");
                } else {
                    System.out.println("Invalid payment amount. Please enter a positive value.");
                }
            } else {
                System.out.println("Student not found.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine(); // Consume the invalid input
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    private static void viewFeeDetails(Scanner scanner) {
        try {
            System.out.print("Enter student username: ");
            String studentUsername = scanner.nextLine();

            int studentIndex = findUser(studentUsername);

            if (studentIndex != -1) {
                System.out.println("Fee details for " + studentUsername + ":");
                System.out.println("Balance: $" + studentBalances[studentIndex]);
            } else {
                System.out.println("Student not found.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    private static void viewTransactionHistory(Scanner scanner) {
        try {
            System.out.print("Enter student username: ");
            String studentUsername = scanner.nextLine();

            int studentIndex = findUser(studentUsername);

            if (studentIndex != -1) {
                System.out.println("Transaction history for " + studentUsername + ":");
                for (int i = 0; i < transactionCount && transactionHistory[i][0] == studentIndex; i++) {
                    System.out.println("Transaction " + (i + 1) + ": $" + transactionHistory[i][1]);
                }
            } else {
                System.out.println("Student not found.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    private static void searchStudentById(Scanner scanner) {
        try {
            System.out.print("Enter student ID: ");
            int studentId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character after nextInt()

            int studentIndex = findStudentById(studentId);

            if (studentIndex != -1) {
                System.out.println("Student found:");
                System.out.println("Name: " + studentNames[studentIndex]);
                System.out.println("Username: " + studentUsernames[studentIndex]);
            } else {
                System.out.println("Student not found.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine(); // Consume the invalid input
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    private static int findStudentById(int studentId) {
        for (int i = 0; i < userCount; i++) {
            if (studentIds[i] == studentId) {
                return i;
            }
        }
        return -1;
    }

    private static void viewAllStudents() {
        System.out.println("List of all students:");

        for (int i = 0; i < userCount; i++) {
            System.out.println((i + 1) + ". " + studentNames[i] + " (ID: " + studentIds[i] + ")");
        }
    }

   
